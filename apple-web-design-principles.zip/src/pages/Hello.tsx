import { useEffect, useRef } from "react";

const LETTERS = Array.from("привет");

type Sample = { t: number; x: number; y: number };

type Piece = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  vr: number;
  flip: number;
  vf: number;
  w: number;
  h: number;
  color: string;
  life: number;
};

const PALETTE = ["#ff375f", "#ff9f0a", "#ffd60a", "#30d158", "#0a84ff", "#bf5af2", "#64d2ff"];
// Cycled by the "Цвет" button; "var(--label)" returns the word to its default.
const WORD_COLORS = ["var(--label)", "#ff375f", "#ff9f0a", "#30d158", "#0a84ff", "#bf5af2"];

type Letter = {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
  vr: number;
  tx: number;
  ty: number;
  tr: number;
  zeta: number;
  resp: number;
  moving: boolean;
};

const MARGIN = 12;
const PANEL_W = 250; // space reserved on the left (desktop)
const PANEL_H = 150; // space reserved at the bottom (mobile)

/* The further past the bound, the less the element follows —
   real things slow down before they stop. */
function rubberband(overshoot: number, dimension: number, constant = 0.55) {
  return (overshoot * dimension * constant) / (dimension + constant * Math.abs(overshoot));
}

const isDesktop = () => window.innerWidth >= 720;

function center() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  return isDesktop()
    ? { cx: (w + PANEL_W) / 2, cy: h / 2 }
    : { cx: w / 2, cy: (h - PANEL_H) / 2 };
}

export default function Hello() {
  const wordRef = useRef<HTMLHeadingElement | null>(null);
  const letterRefs = useRef<(HTMLSpanElement | null)[]>([]);

  // All motion state lives outside React — the rAF loop reads and writes it
  // directly so the word never waits on a render to respond to input.
  const s = useRef({
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    tx: 0,
    ty: 0,
    zeta: 1,
    scale: 1,
    dragging: false,
    springing: false,
    grabX: 0,
    grabY: 0,
    downT: 0,
    downX: 0,
    downY: 0,
    history: [] as Sample[],
    intro: 0,
    introAt: -1,
    lastSpeed: 0,
    settled: true,
    rot: 0,
    rotV: 0,
    rotZ: 0.5,
    tiltX: 0,
    tiltY: 0,
    tiltTX: 0,
    tiltTY: 0,
    afterDrop: false,
    pulse: 0, // reduced-motion feedback, 1 → 0
  }).current;

  const letters = useRef<Letter[]>(
    LETTERS.map(() => ({
      x: 0,
      y: 0,
      r: 0,
      vx: 0,
      vy: 0,
      vr: 0,
      tx: 0,
      ty: 0,
      tr: 0,
      zeta: 1,
      resp: 0.3,
      moving: false,
    })),
  ).current;

  const timers = useRef<number[]>([]);
  const confetti = useRef<Piece[]>([]);
  const fxRef = useRef<HTMLCanvasElement | null>(null);
  const hueIdx = useRef(0);
  const reducedMotion = useRef(false);

  const haptic = (ms = 8) => {
    if ("vibrate" in navigator) navigator.vibrate(ms);
  };

  const later = (fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms));
  };

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    reducedMotion.current = mq.matches;
    const onMotionPref = () => {
      reducedMotion.current = mq.matches;
    };
    mq.addEventListener("change", onMotionPref);

    s.introAt = performance.now();

    let raf = 0;
    let last = performance.now();

    const loop = (now: number) => {
      const dt = Math.min((now - last) / 1000, 1 / 30);
      last = now;

      // 1. Entrance — materialize: blur + scale + opacity arrive together.
      if (s.intro < 1) {
        const reduced = reducedMotion.current;
        const t = (now - s.introAt - (reduced ? 0 : 140)) / (reduced ? 200 : 640);
        s.intro = t <= 0 ? 0 : t >= 1 ? 1 : 1 - Math.pow(1 - t, 3);
      }

      // 2. Press feedback — scale dips the instant the pointer goes down.
      const targetScale = s.dragging ? 0.965 : 1;
      if (Math.abs(s.scale - targetScale) > 0.0004) {
        s.scale += (targetScale - s.scale) * Math.min(1, dt * 34);
      } else {
        s.scale = targetScale;
      }

      // 3. Cursor parallax tilt — the word turns a few degrees toward you.
      if (!reducedMotion.current) {
        const k = Math.min(1, dt * 5);
        s.tiltX += (s.tiltTX - s.tiltX) * k;
        s.tiltY += (s.tiltTY - s.tiltY) * k;
      }

      // 4. Word-level rotation spring (the ";)" wobble).
      if (Math.abs(s.rot) > 0.01 || Math.abs(s.rotV) > 0.5) {
        const omega = (2 * Math.PI) / 0.4;
        const k = omega * omega;
        const c = 2 * s.rotZ * Math.sqrt(k);
        let rem = dt;
        while (rem > 1e-4) {
          const stp = Math.min(1 / 240, rem);
          rem -= stp;
          s.rotV += (-k * s.rot - c * s.rotV) * stp;
          s.rot += s.rotV * stp;
        }
        if (Math.abs(s.rot) < 0.01 && Math.abs(s.rotV) < 0.5) {
          s.rot = 0;
          s.rotV = 0;
        }
      }

      // 5. Per-letter springs (wave, scramble) — each is an independent
      //    interruptible spring that re-targets from its live value.
      for (const L of letters) {
        if (!L.moving) continue;
        const omega = (2 * Math.PI) / L.resp;
        const k = omega * omega;
        const c = 2 * L.zeta * Math.sqrt(k);
        let rem = dt;
        while (rem > 1e-4) {
          const stp = Math.min(1 / 240, rem);
          rem -= stp;
          L.vx += (-k * (L.x - L.tx) - c * L.vx) * stp;
          L.vy += (-k * (L.y - L.ty) - c * L.vy) * stp;
          L.vr += (-k * (L.r - L.tr) - c * L.vr) * stp;
          L.x += L.vx * stp;
          L.y += L.vy * stp;
          L.r += L.vr * stp;
        }
        if (
          Math.hypot(L.x - L.tx, L.y - L.ty, L.r - L.tr) < 0.25 &&
          Math.hypot(L.vx, L.vy, L.vr) < 6
        ) {
          L.x = L.tx;
          L.y = L.ty;
          L.r = L.tr;
          L.vx = 0;
          L.vy = 0;
          L.vr = 0;
          L.moving = false;
        }
      }

      // 6. Main x/y spring — velocity-aware, interruptible every frame.
      if (s.springing && !s.dragging) {
        const omega = (2 * Math.PI) / 0.34;
        const k = omega * omega;
        const c = 2 * s.zeta * Math.sqrt(k);
        let rem = dt;
        while (rem > 1e-4) {
          const stp = Math.min(1 / 240, rem);
          rem -= stp;
          s.vx += (-k * (s.x - s.tx) - c * s.vx) * stp;
          s.vy += (-k * (s.y - s.ty) - c * s.vy) * stp;
          s.x += s.vx * stp;
          s.y += s.vy * stp;
        }
        const dist = Math.hypot(s.x - s.tx, s.y - s.ty);
        const speed = Math.hypot(s.vx, s.vy);
        if (dist < 0.1 && speed < 4) {
          s.x = s.tx;
          s.y = s.ty;
          s.vx = 0;
          s.vy = 0;
          s.springing = false;
          if (s.afterDrop) {
            // The "Real?" drop lands — impact tick, then spring back up.
            s.afterDrop = false;
            haptic(12);
            s.tx = 0;
            s.ty = 0;
            s.zeta = 0.8;
            s.springing = true;
            s.settled = false;
            s.vx = (Math.random() - 0.5) * 160;
          } else if (!s.settled && s.lastSpeed > 1500) {
            haptic(8);
          }
          s.settled = true;
        }
      }

      // 7. Reduced-motion gentle pulse (non-vestibular feedback).
      if (s.pulse > 0) s.pulse = Math.max(0, s.pulse - dt / 0.32);

      // 8. Write the frame — compositor-only properties.
      const el = wordRef.current;
      if (el) {
        const reduced = reducedMotion.current;
        const introScale = reduced ? 1 : 0.955 + 0.045 * s.intro;
        const blur = reduced ? 0 : 12 * (1 - s.intro);
        el.style.transform = `translate3d(${s.x}px, ${s.y}px, 0) rotateX(${s.tiltX.toFixed(2)}deg) rotateY(${s.tiltY.toFixed(2)}deg) rotateZ(${s.rot.toFixed(2)}deg) scale(${(s.scale * introScale).toFixed(4)})`;
        el.style.opacity = (s.intro * (1 - 0.35 * s.pulse)).toFixed(3);
        el.style.filter = blur > 0.15 ? `blur(${blur.toFixed(2)}px)` : "";
      }
      letters.forEach((L, i) => {
        const lEl = letterRefs.current[i];
        if (lEl)
          lEl.style.transform = `translate3d(${L.x.toFixed(2)}px, ${L.y.toFixed(2)}px, 0) rotate(${L.r.toFixed(2)}deg)`;
      });

      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      timers.current.forEach(clearTimeout);
      mq.removeEventListener("change", onMotionPref);
    };
  }, [s, letters]);

  /* ---------- actions (panel buttons + word tap) ---------- */

  // HI! — letters hop up in a staggered wave.
  const doWave = () => {
    haptic();
    if (reducedMotion.current) {
      s.pulse = 1;
      return;
    }
    LETTERS.forEach((_, i) =>
      later(() => {
        const L = letters[i];
        L.vy = -(620 + i * 55);
        L.zeta = 0.62;
        L.resp = 0.42;
        L.moving = true;
      }, i * 45),
    );
  };

  // ;) — the whole word swings like a playful shoulder shrug.
  const doTilt = () => {
    haptic();
    if (reducedMotion.current) {
      s.pulse = 1;
      return;
    }
    s.rotZ = 0.5;
    s.rotV = (Math.random() > 0.5 ? 1 : -1) * 460;
  };

  // You actually read this — letters scatter, then re-assemble.
  const doScramble = () => {
    haptic();
    if (reducedMotion.current) {
      s.pulse = 1;
      return;
    }
    letters.forEach((L, i) => {
      const ang = Math.random() * Math.PI * 2;
      const dist = 70 + Math.random() * 120;
      L.tx = Math.cos(ang) * dist;
      L.ty = Math.sin(ang) * dist * 0.6;
      L.tr = (Math.random() - 0.5) * 70;
      L.resp = 0.22;
      L.zeta = 1;
      L.moving = true;
      later(() => {
        L.tx = 0;
        L.ty = 0;
        L.tr = 0;
        L.resp = 0.32;
        L.zeta = 0.8;
      }, 320 + i * 30 + Math.random() * 300);
    });
  };

  // Real? — the word falls, thunks off the bottom, and springs back.
  const doDrop = () => {
    haptic();
    if (reducedMotion.current) {
      s.pulse = 1;
      return;
    }
    const el = wordRef.current!;
    const { cy } = center();
    const drop = window.innerHeight - cy - el.offsetHeight / 2 - 14;
    s.tx = (Math.random() - 0.5) * 60;
    s.ty = drop;
    s.zeta = 0.5;
    s.springing = true;
    s.settled = false;
    s.afterDrop = true;
    s.lastSpeed = 0;
  };

  // 🎉 Конфетти — 150 pieces burst out of the word with drag + gravity.
  const doBurst = () => {
    haptic(14);
    if (reducedMotion.current) {
      s.pulse = 1;
      return;
    }
    const { cx, cy } = center();
    const ox = cx + s.x;
    const oy = cy + s.y;
    for (let i = 0; i < 150; i++) {
      const a = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI * 1.5;
      const sp = 380 + Math.random() * 820;
      confetti.current.push({
        x: ox + (Math.random() - 0.5) * 140,
        y: oy + (Math.random() - 0.5) * 40,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        r: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 12,
        flip: Math.random() * Math.PI * 2,
        vf: 6 + Math.random() * 8,
        w: 7 + Math.random() * 7,
        h: 4 + Math.random() * 4,
        color: PALETTE[i % PALETTE.length],
        life: 2.4 + Math.random() * 1.6,
      });
    }
  };

  // 🎨 Цвет — cycles the word through a palette; the colour eases over 420 ms.
  const doColor = () => {
    haptic();
    if (!wordRef.current) return;
    hueIdx.current = (hueIdx.current + 1) % WORD_COLORS.length;
    wordRef.current.style.color = WORD_COLORS[hueIdx.current];
  };

  // Canvas loop for confetti — independent of the word's spring loop.
  useEffect(() => {
    const canvas = fxRef.current!;
    const ctx = canvas.getContext("2d")!;
    const fit = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    fit();
    window.addEventListener("resize", fit);

    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min((now - last) / 1000, 1 / 30);
      last = now;
      const ps = confetti.current;
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      for (let i = ps.length - 1; i >= 0; i--) {
        const p = ps[i];
        p.life -= dt;
        if (p.life <= 0 || p.y > window.innerHeight + 40) {
          ps.splice(i, 1);
          continue;
        }
        // Air drag + gravity: pieces burst, slow down, then flutter down.
        const drag = Math.exp(-2.2 * dt);
        p.vx *= drag;
        p.vy = p.vy * drag + 1500 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.r += p.vr * dt;
        p.flip += p.vf * dt;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.r);
        ctx.scale(1, Math.cos(p.flip)); // paper-flip effect
        ctx.globalAlpha = Math.min(1, p.life * 1.6);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        ctx.restore();
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", fit);
    };
  }, []);

  /* ---------- word drag / tap ---------- */

  const bounds = () => {
    const el = wordRef.current!;
    return {
      maxX: Math.max(0, (window.innerWidth - el.offsetWidth) / 2 - MARGIN),
      maxY: Math.max(0, (window.innerHeight - el.offsetHeight) / 2 - MARGIN),
    };
  };

  const clampToBounds = (x: number, y: number, soft: boolean) => {
    const { maxX, maxY } = bounds();
    let nx = x;
    let ny = y;
    if (soft) {
      if (nx > maxX) nx = maxX + rubberband(nx - maxX, window.innerWidth);
      if (nx < -maxX) nx = -maxX - rubberband(-(nx + maxX), window.innerWidth);
      if (ny > maxY) ny = maxY + rubberband(ny - maxY, window.innerHeight);
      if (ny < -maxY) ny = -maxY - rubberband(-(ny + maxY), window.innerHeight);
    } else {
      nx = Math.max(-maxX, Math.min(maxX, nx));
      ny = Math.max(-maxY, Math.min(maxY, ny));
    }
    return { x: nx, y: ny };
  };

  const onPointerDown = (e: React.PointerEvent<HTMLHeadingElement>) => {
    if (!e.isPrimary || s.dragging) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    // Respect where the finger actually grabbed — never snap to center.
    const { cx, cy } = center();
    s.grabX = e.clientX - (cx + s.x);
    s.grabY = e.clientY - (cy + s.y);
    s.downT = performance.now();
    s.downX = e.clientX;
    s.downY = e.clientY;
    s.dragging = true;
    s.springing = false;
    s.history = [{ t: performance.now(), x: s.x, y: s.y }];
    e.currentTarget.style.cursor = "grabbing";
  };

  const onPointerMove = (e: React.PointerEvent<HTMLHeadingElement>) => {
    if (!s.dragging || !e.isPrimary) return;
    e.preventDefault();
    const { cx, cy } = center();
    const { x, y } = clampToBounds(
      e.clientX - s.grabX - cx,
      e.clientY - s.grabY - cy,
      true,
    );
    s.x = x;
    s.y = y;
    const now = performance.now();
    // Short position history — release velocity comes from it.
    s.history.push({ t: now, x, y });
    while (s.history.length > 2 && now - s.history[0].t > 130) s.history.shift();
  };

  const endDrag = (e: React.PointerEvent<HTMLHeadingElement>) => {
    if (!s.dragging || !e.isPrimary) return;
    s.dragging = false;
    e.currentTarget.style.cursor = "grab";

    // A clean, quick tap (not a drag) = the word says hi back.
    const moved = Math.hypot(e.clientX - s.downX, e.clientY - s.downY);
    const quick = performance.now() - s.downT < 280;
    if (moved < 9 && quick) {
      s.history = [];
      doWave();
      return;
    }

    // Release velocity, averaged over the last ~110 ms of the gesture.
    const h = s.history;
    let vx = 0;
    let vy = 0;
    if (h.length >= 2) {
      const a = h[h.length - 1];
      let b = h[0];
      for (let i = 0; i < h.length - 1; i++) {
        if (a.t - h[i].t <= 110) {
          b = h[i];
          break;
        }
      }
      const dts = (a.t - b.t) / 1000;
      if (dts > 0.008) {
        vx = (a.x - b.x) / dts;
        vy = (a.y - b.y) / dts;
      }
    }

    s.tx = 0;
    s.ty = 0;
    s.history = [];

    if (reducedMotion.current) {
      s.x = 0;
      s.y = 0;
      s.vx = 0;
      s.vy = 0;
      s.springing = false;
      return;
    }

    // Hand the finger's exact velocity to the spring — no visible seam.
    s.vx = vx;
    s.vy = vy;
    s.lastSpeed = Math.hypot(vx, vy);
    s.settled = false;
    s.afterDrop = false;
    // A little bounce only when the gesture itself carried momentum.
    s.zeta = s.lastSpeed > 900 ? 0.8 : 1;
    s.springing = Math.hypot(s.x, s.y) > 0.5 || s.lastSpeed > 20;
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLHeadingElement>) => {
    const step = 48;
    let tx = s.tx;
    let ty = s.ty;
    if (e.key === "ArrowLeft") tx -= step;
    else if (e.key === "ArrowRight") tx += step;
    else if (e.key === "ArrowUp") ty -= step;
    else if (e.key === "ArrowDown") ty += step;
    else if (e.key === "Enter" || e.key === " " || e.key === "Home" || e.key === "Escape") {
      tx = 0;
      ty = 0;
    } else return;
    e.preventDefault();
    const { x, y } = clampToBounds(tx, ty, false);
    s.tx = x;
    s.ty = y;
    if (reducedMotion.current) {
      s.x = x;
      s.y = y;
      s.springing = false;
    } else {
      s.zeta = 1;
      s.springing = true;
      s.settled = false;
    }
  };

  const onStageMove = (e: React.PointerEvent<HTMLElement>) => {
    if (s.dragging || reducedMotion.current) return;
    s.tiltTY = (1 - 2 * (e.clientY / window.innerHeight)) * 4.5;
    s.tiltTX = (2 * (e.clientX / window.innerWidth) - 1) * 6.5;
  };

  const onStageLeave = () => {
    s.tiltTX = 0;
    s.tiltTY = 0;
  };

  return (
    <main className="stage" onPointerMove={onStageMove} onPointerLeave={onStageLeave}>
      <canvas ref={fxRef} className="fx" aria-hidden="true" />

      <nav className="panel" aria-label="Приветствия">
        <button type="button" className="pbtn" onClick={doWave}>
          HI!
        </button>
        <button type="button" className="pbtn" onClick={doTilt}>
          ;)
        </button>
        <button type="button" className="pbtn" onClick={doScramble}>
          You actually read this
        </button>
        <button type="button" className="pbtn" onClick={doDrop}>
          Real?
        </button>
        <button type="button" className="pbtn" onClick={doBurst}>
          🎉 Конфетти
        </button>
        <button type="button" className="pbtn" onClick={doColor}>
          🎨 Цвет
        </button>
      </nav>

      <h1
        ref={wordRef}
        className="word"
        style={{ opacity: 0 }}
        tabIndex={0}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onKeyDown={onKeyDown}
      >
        {LETTERS.map((ch, i) => (
          <span
            key={i}
            ref={(el) => {
              letterRefs.current[i] = el;
            }}
            className="ltr"
          >
            {ch}
          </span>
        ))}
      </h1>
    </main>
  );
}
