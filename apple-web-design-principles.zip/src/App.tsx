import { useState, type ComponentType } from "react";
import "./lab/lab.css";
import Hello from "./pages/Hello";
import ButtonDepth from "./lab/ButtonDepth";
import Terminal from "./lab/Terminal";
import PhysicsDrop from "./lab/PhysicsDrop";
import LiquidGlass from "./lab/LiquidGlass";
import { PasswordGen, ReverseText } from "./lab/TextTools";
import GithubCard from "./lab/GithubCard";
import SignupForm from "./lab/SignupForm";
import Meow from "./lab/Meow";

type Tab = {
  id: string;
  label: string;
  title?: string; // no title = full-screen page (the hello word)
  task?: string;
  Component: ComponentType;
};

const TABS: Tab[] = [
  { id: "hello", label: "Привет", Component: Hello },
  {
    id: "depth",
    label: "3D-кнопка",
    title: "Кнопка, которая проваливается",
    task: "Только CSS: perspective и transform, никакого JS.",
    Component: ButtonDepth,
  },
  {
    id: "terminal",
    label: "Терминал",
    title: "Терминал хакера 80-х",
    task: "Зелёный текст, CRT-мерцание и сканлайны; типографика по Apple Design.",
    Component: Terminal,
  },
  {
    id: "physics",
    label: "Физика",
    title: "Падение с g = 9.8",
    task: "Перетащи мяч и отпусти: свободное падение, отскок e = 0.6 и остановка от трения.",
    Component: PhysicsDrop,
  },
  {
    id: "glass",
    label: "Liquid Glass",
    title: "Жидкое стекло",
    task: "Наведи курсор на карточку: фон под ней искажается, как через лупу.",
    Component: LiquidGlass,
  },
  {
    id: "password",
    label: "Пароль",
    title: "Произносимый пароль",
    task: "Чередование согласных и гласных, минимум одна цифра, без сторонних библиотек.",
    Component: PasswordGen,
  },
  {
    id: "reverse",
    label: "Реверс",
    title: "Реверс строки",
    task: "Только рекурсия: без .reverse(), .split() и циклов.",
    Component: ReverseText,
  },
  {
    id: "github",
    label: "GitHub",
    title: "Карточка GitHub",
    task: "fetch к api.github.com, скелетон при загрузке и обработка ошибок.",
    Component: GithubCard,
  },
  {
    id: "signup",
    label: "Форма",
    title: "Регистрация",
    task: "Клиентская валидация Zod и отправка на Express-сервер с SQLite.",
    Component: SignupForm,
  },
  {
    id: "meow",
    label: "Мяу",
    title: "Кнопка «Мяу»",
    task: "Звук через Web Audio API. При повторном клике страница становится розовой и крутится.",
    Component: Meow,
  },
];

export default function App() {
  const [activeId, setActiveId] = useState("hello");
  const tab = TABS.find((t) => t.id === activeId) ?? TABS[0];
  const Current = tab.Component;

  return (
    <div className="lab">
      <nav className="lab-nav" aria-label="Разделы">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            className="lab-tab"
            aria-current={t.id === activeId ? "page" : undefined}
            onClick={() => setActiveId(t.id)}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <div
        key={tab.id}
        className={tab.title ? "lab-page" : "lab-page lab-page--full"}
      >
        {tab.title ? (
          <section className="lab-section">
            <header className="lab-head">
              <h1>{tab.title}</h1>
              <p>{tab.task}</p>
            </header>
            <Current />
          </section>
        ) : (
          <Current />
        )}
      </div>
    </div>
  );
}
