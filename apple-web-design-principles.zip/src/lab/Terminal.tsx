import { useEffect, useRef, useState, type FormEvent } from "react";

const BOOT = [
  "ARENA-OS v1.0  (c) 1984 Apple Lab Systems",
  "Memory test ........ 640K OK",
  "Loading typeface ... SF Mono OK",
  "Type 'help' for commands.",
  "",
];

function run(cmd: string): string[] | "clear" {
  switch (cmd) {
    case "":
      return [];
    case "help":
      return [
        "  help    — список команд",
        "  whoami  — кто ты",
        "  date    — текущее время",
        "  clear   — очистить экран",
      ];
    case "whoami":
      return ["guest@arena"];
    case "date":
      return [new Date().toLocaleString("ru-RU")];
    case "clear":
      return "clear";
    default:
      return [`command not found: ${cmd}`];
  }
}

export default function Terminal() {
  const [lines, setLines] = useState<string[]>(BOOT);
  const [cmd, setCmd] = useState("");
  const screenRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = screenRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines]);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const c = cmd.trim().toLowerCase();
    const out = run(c);
    if (out === "clear") setLines([]);
    else setLines((prev) => [...prev, `$ ${cmd}`, ...out]);
    setCmd("");
  };

  return (
    <div className="crt">
      <div className="crt-text" ref={screenRef}>
        {lines.map((line, i) => (
          <div key={i}>{line || "\u00a0"}</div>
        ))}
        <form className="crt-line" onSubmit={onSubmit}>
          <span>$</span>
          <input
            className="crt-input"
            value={cmd}
            onChange={(e) => setCmd(e.target.value)}
            aria-label="Команда"
            autoComplete="off"
            spellCheck={false}
          />
        </form>
      </div>
    </div>
  );
}
