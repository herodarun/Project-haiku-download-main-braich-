import { useState, type FormEvent } from "react";
import { z } from "zod";

// Та же схема, что и на сервере (server/index.mjs): клиент проверяет до отправки.
const SignupSchema = z.object({
  email: z.string().trim().email("Введите корректный email"),
  age: z.number().int("Возраст — целое число").gt(18, "Возраст должен быть больше 18"),
});

const API_URL = "http://localhost:3001";

type Values = { email: string; age: string };
type Errors = Partial<Record<keyof Values, string>>;

function validate(v: Values): Errors {
  const errors: Errors = {};
  if (v.age.trim() === "") errors.age = "Укажите возраст";
  const res = SignupSchema.safeParse({ email: v.email, age: Number(v.age) });
  if (!res.success) {
    for (const issue of res.error.issues) {
      const key = String(issue.path[0]) as keyof Values;
      if (!errors[key]) errors[key] = issue.message;
    }
  }
  return errors;
}

type Status =
  | { kind: "idle" }
  | { kind: "sending" }
  | { kind: "ok"; id: number }
  | { kind: "error"; message: string };

export default function SignupForm() {
  const [values, setValues] = useState<Values>({ email: "", age: "" });
  const [touched, setTouched] = useState<Partial<Record<keyof Values, boolean>>>({});
  const [submitted, setSubmitted] = useState(false);
  const [serverErrors, setServerErrors] = useState<Errors>({});
  const [status, setStatus] = useState<Status>({ kind: "idle" });

  const errors = { ...validate(values), ...serverErrors };
  const showError = (k: keyof Values) => (touched[k] || submitted ? errors[k] : undefined);

  const update = (k: keyof Values, v: string) => {
    setValues((prev) => ({ ...prev, [k]: v }));
    setServerErrors((prev) => ({ ...prev, [k]: undefined }));
  };

  const blur = (k: keyof Values) => setTouched((prev) => ({ ...prev, [k]: true }));

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    if (Object.keys(validate(values)).length > 0) return;

    setStatus({ kind: "sending" });
    setServerErrors({});
    try {
      const res = await fetch(`${API_URL}/api/signup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: values.email.trim(), age: Number(values.age) }),
      });
      const data = await res.json().catch(() => ({}));

      if (res.status === 201) {
        setStatus({ kind: "ok", id: data.id });
        setValues({ email: "", age: "" });
        setTouched({});
        setSubmitted(false);
        return;
      }
      if (res.status === 400 || res.status === 409) {
        setServerErrors({ email: data.errors?.email?.[0], age: data.errors?.age?.[0] });
        setStatus({ kind: "idle" });
        return;
      }
      setStatus({ kind: "error", message: `Сервер ответил ошибкой ${res.status}` });
    } catch {
      setStatus({
        kind: "error",
        message: "Сервер не отвечает. Запустите: node server/index.mjs",
      });
    }
  };

  const emailErr = showError("email");
  const ageErr = showError("age");

  return (
    <form className="lab-card sf" onSubmit={onSubmit} noValidate>
      <label className="sf-field">
        Email
        <input
          className="lab-input"
          type="email"
          value={values.email}
          onChange={(e) => update("email", e.target.value)}
          onBlur={() => blur("email")}
          aria-invalid={emailErr ? "true" : "false"}
          autoComplete="email"
          placeholder="you@example.com"
        />
        {emailErr && <p className="lab-error">{emailErr}</p>}
      </label>

      <label className="sf-field">
        Возраст
        <input
          className="lab-input"
          type="number"
          inputMode="numeric"
          value={values.age}
          onChange={(e) => update("age", e.target.value)}
          onBlur={() => blur("age")}
          aria-invalid={ageErr ? "true" : "false"}
          placeholder="18+"
        />
        {ageErr && <p className="lab-error">{ageErr}</p>}
      </label>

      <div className="sf-row">
        <button type="submit" className="lab-btn" disabled={status.kind === "sending"}>
          {status.kind === "sending" ? "Отправка…" : "Зарегистрироваться"}
        </button>
        {status.kind === "ok" && (
          <p className="sf-ok">Готово! Запись #{status.id} сохранена в SQLite.</p>
        )}
        {status.kind === "error" && <p className="lab-error">{status.message}</p>}
      </div>
    </form>
  );
}
