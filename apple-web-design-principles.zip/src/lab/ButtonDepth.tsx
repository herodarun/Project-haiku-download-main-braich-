export default function ButtonDepth() {
  return (
    <div className="depth-stage">
      <div className="depth-well">
        <button type="button" className="depth-btn">
          Нажми и держи
        </button>
      </div>
      <p className="depth-cap">
        Ни строчки JS: только <code>perspective</code> и <code>transform</code> в состоянии <code>:active</code>
      </p>
    </div>
  );
}
