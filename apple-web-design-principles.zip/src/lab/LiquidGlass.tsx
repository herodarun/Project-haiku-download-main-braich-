import { useEffect, useMemo, useRef } from "react";

const W = 320;
const H = 200;
const LENS_R = Math.min(W, H) / 2; // радиус линзы
const MAP_RANGE = 120; // диапазон смещения (px), закодированный в карте

const ROW_COLORS = ["#ff375f", "#ff9f0a", "#ffd60a", "#30d158", "#64d2ff", "#bf5af2"];

/*
 * Карта смещений для feDisplacementMap: красный канал — смещение по X,
 * зелёный — по Y. Внутри линзы выборка сжимается к центру (эффект лупы),
 * на краю плавно сходит на нет, снаружи смещения нет.
 */
function makeLensMap(): string {
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d")!;
  const img = ctx.createImageData(W, H);
  const cx = W / 2;
  const cy = H / 2;

  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const dx = x - cx;
      const dy = y - cy;
      const d = Math.hypot(dx, dy) / LENS_R;
      let ox = 0;
      let oy = 0;
      if (d < 1) {
        const m = 1 - 0.8 * (1 - d) * (1 - d); // масштаб выборки: 0.2 в центре → 1 на краю
        ox = dx * (m - 1);
        oy = dy * (m - 1);
      }
      const i = (y * W + x) * 4;
      img.data[i] = Math.round(clamp01(0.5 + ox / MAP_RANGE) * 255);
      img.data[i + 1] = Math.round(clamp01(0.5 + oy / MAP_RANGE) * 255);
      img.data[i + 2] = 128;
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  return canvas.toDataURL();
}

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

export default function LiquidGlass() {
  const dispRef = useRef<SVGFEDisplacementMapElement>(null);
  const target = useRef(0);
  const current = useRef(0);
  const map = useMemo(() => makeLensMap(), []);

  // Smoothly ease the lens strength in/out so the distortion breathes
  // instead of snapping on hover.
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min((now - last) / 1000, 1 / 30);
      last = now;
      current.current += (target.current - current.current) * Math.min(1, dt * 9);
      if (Math.abs(target.current - current.current) < 0.001) current.current = target.current;
      // displacement = scale · (R − 0.5); with R = 0.5 + ox / MAP_RANGE this equals intensity · ox
      dispRef.current?.setAttribute("scale", String(current.current * MAP_RANGE));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="glass-stage">
      <svg
        aria-hidden="true"
        width="0"
        height="0"
        style={{ position: "absolute", width: 0, height: 0 }}
      >
        <filter id="liquid-lens" x="0" y="0" width="1" height="1" colorInterpolationFilters="sRGB">
          <feImage href={map} x="0" y="0" width={W} height={H} preserveAspectRatio="none" result="lens" />
          <feDisplacementMap
            ref={dispRef}
            in="SourceGraphic"
            in2="lens"
            scale="0"
            xChannelSelector="R"
            yChannelSelector="G"
          />
        </filter>
      </svg>

      <div className="glass-bg" aria-hidden="true">
        {ROW_COLORS.map((color, r) => (
          <div
            key={r}
            className="glass-row"
            style={{ color, animationDelay: `${-r * 1.3}s` }}
          >
            {"LIQUID GLASS ✦ IOS 26 ✦ ".repeat(4)}
          </div>
        ))}
      </div>

      <div
        className="glass-card"
        onPointerEnter={() => {
          target.current = 1;
        }}
        onPointerLeave={() => {
          target.current = 0;
        }}
      >
        <div className="glass-title">Наведи</div>
        <div className="glass-sub">фон под стеклом изгибается</div>
      </div>
    </div>
  );
}
