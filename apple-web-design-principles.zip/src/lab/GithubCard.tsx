import { useEffect, useState } from "react";

type GhUser = {
  login: string;
  name: string | null;
  avatar_url: string;
  bio: string | null;
  public_repos: number;
  followers: number;
  html_url: string;
};

type State =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ok"; user: GhUser };

export default function GithubCard() {
  const [query, setQuery] = useState("torvalds");
  const [draft, setDraft] = useState("torvalds");
  const [retry, setRetry] = useState(0);
  const [state, setState] = useState<State>({ status: "loading" });

  useEffect(() => {
    const ctrl = new AbortController();
    setState({ status: "loading" });

    fetch(`https://api.github.com/users/${encodeURIComponent(query)}`, {
      signal: ctrl.signal,
      headers: { Accept: "application/vnd.github+json" },
    })
      .then(async (res) => {
        if (res.status === 404) throw new Error("Пользователь не найден");
        if (res.status === 403 || res.status === 429)
          throw new Error("Лимит запросов к GitHub исчерпан, попробуйте позже");
        if (!res.ok) throw new Error(`Сервер ответил ошибкой ${res.status}`);
        return (await res.json()) as GhUser;
      })
      .then((user) => setState({ status: "ok", user }))
      .catch((err: unknown) => {
        if (ctrl.signal.aborted) return;
        const message =
          err instanceof TypeError
            ? "Нет соединения с сетью"
            : err instanceof Error
              ? err.message
              : "Неизвестная ошибка";
        setState({ status: "error", message });
      });

    return () => ctrl.abort();
  }, [query, retry]);

  return (
    <div className="lab-card gh">
      <form
        className="gh-form"
        onSubmit={(e) => {
          e.preventDefault();
          const v = draft.trim();
          if (v) setQuery(v);
        }}
      >
        <input
          className="lab-input"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          aria-label="Имя пользователя GitHub"
          placeholder="username"
          autoComplete="off"
          spellCheck={false}
        />
        <button type="submit" className="lab-btn">
          Найти
        </button>
      </form>

      {state.status === "loading" && (
        <div className="gh-skel" aria-busy="true" aria-label="Загрузка">
          <div className="skel gh-avatar-sk" />
          <div className="gh-lines">
            <div className="skel" style={{ height: 22, width: "55%" }} />
            <div className="skel" style={{ height: 14, width: "35%" }} />
            <div className="skel" style={{ height: 14, width: "75%" }} />
          </div>
        </div>
      )}

      {state.status === "error" && (
        <div className="gh-error" role="alert">
          <p>⚠️ {state.message}</p>
          <button
            type="button"
            className="lab-btn lab-btn--ghost"
            onClick={() => setRetry((n) => n + 1)}
          >
            Повторить
          </button>
        </div>
      )}

      {state.status === "ok" && (
        <a className="gh-user" href={state.user.html_url} target="_blank" rel="noreferrer">
          <img className="gh-avatar" src={state.user.avatar_url} alt="" />
          <div>
            <div className="gh-name">{state.user.name ?? state.user.login}</div>
            <div className="gh-login">@{state.user.login}</div>
            {state.user.bio && <p className="gh-bio">{state.user.bio}</p>}
          </div>
          <div className="gh-stats">
            <div>
              <b>{state.user.public_repos.toLocaleString("ru-RU")}</b>
              <span>репозиториев</span>
            </div>
            <div>
              <b>{state.user.followers.toLocaleString("ru-RU")}</b>
              <span>подписчиков</span>
            </div>
          </div>
        </a>
      )}
    </div>
  );
}
