import { useEffect, useRef, useState } from "react";

/* Синтез «мяу» без mp3: пилообразный тон с глиссандо вверх-вниз,
   вибрато и полосовой фильтр, который ведёт себя как гласная. */
function playMeow(ctx: AudioContext) {
  const t = ctx.currentTime;
  const osc = ctx.createOscillator();
  const vibrato = ctx.createOscillator();
  const vibratoDepth = ctx.createGain();
  const formant = ctx.createBiquadFilter();
  const gain = ctx.createGain();

  // «мяяя-уууу»: высота сначала тянется вверх, затем падает
  osc.type = "sawtooth";
  osc.frequency.setValueAtTime(560, t);
  osc.frequency.linearRampToValueAtTime(980, t + 0.22);
  osc.frequency.exponentialRampToValueAtTime(430, t + 0.8);

  vibrato.frequency.value = 7;
  vibratoDepth.gain.value = 22;
  vibrato.connect(vibratoDepth).connect(osc.frequency);

  // формантная «гласная»: от «и» к «а»-подобной
  formant.type = "bandpass";
  formant.Q.value = 5;
  formant.frequency.setValueAtTime(1100, t);
  formant.frequency.linearRampToValueAtTime(2300, t + 0.2);
  formant.frequency.exponentialRampToValueAtTime(650, t + 0.85);

  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(0.6, t + 0.08);
  gain.gain.linearRampToValueAtTime(0.45, t + 0.4);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.95);

  osc.connect(formant).connect(gain).connect(ctx.destination);
  osc.start(t);
  vibrato.start(t);
  osc.stop(t + 1);
  vibrato.stop(t + 1);
}

export default function Meow() {
  const ctxRef = useRef<AudioContext | null>(null);
  const [clicks, setClicks] = useState(0);
  const [party, setParty] = useState(false);

  // Вечеринка — класс на <body>; снимаем при выходе со страницы.
  useEffect(() => {
    document.body.classList.toggle("party", party);
    return () => document.body.classList.remove("party");
  }, [party]);

  const onMeow = () => {
    if (!ctxRef.current) ctxRef.current = new AudioContext();
    if (ctxRef.current.state === "suspended") void ctxRef.current.resume();
    playMeow(ctxRef.current);

    const next = clicks + 1;
    setClicks(next);
    if (next >= 2) setParty(true);
  };

  const hint =
    clicks === 0
      ? "Нажми на кота"
      : party
        ? "Вечеринка! Страница крутится"
        : "Ещё раз — и страница сойдёт с ума";

  return (
    <div className="meow">
      <button type="button" className="meow-btn" onClick={onMeow} aria-label="Мяу">
        <span aria-hidden="true">🐱</span>
      </button>
      <p className="meow-count">{hint}</p>
      {party && (
        <button
          type="button"
          className="lab-btn lab-btn--ghost"
          onClick={() => {
            setParty(false);
            setClicks(0);
          }}
        >
          Стоп
        </button>
      )}
    </div>
  );
}
