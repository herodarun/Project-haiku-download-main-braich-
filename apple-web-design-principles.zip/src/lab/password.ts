const CONSONANTS = "bcdfghjklmnprstvz";
const VOWELS = "aeiou";
const DIGITS = "0123456789";

/** Несмещённое случайное число в [0, max) на Web Crypto (без библиотек). */
function randomIndex(max: number): number {
  const buf = new Uint32Array(1);
  const limit = Math.floor(0x100000000 / max) * max; // rejection sampling
  let n: number;
  do {
    crypto.getRandomValues(buf);
    n = buf[0];
  } while (n >= limit);
  return n % max;
}

function pick(pool: string): string {
  return pool[randomIndex(pool.length)];
}

/**
 * Произносимый пароль: согласная–гласная–согласная…, первая буква заглавная,
 * в конце обязательно цифра.
 */
export function generatePassword(length = 12): string {
  const core = Math.max(6, length - 1); // один символ зарезервирован под цифру
  let out = "";
  for (let i = 0; i < core; i++) {
    out += i % 2 === 0 ? pick(CONSONANTS) : pick(VOWELS);
  }
  return out[0].toUpperCase() + out.slice(1) + pick(DIGITS);
}

/** Проверка: чередуются ли согласные и гласные, и есть ли цифра. */
export function checkPassword(pw: string): { pronounceable: boolean; hasDigit: boolean } {
  const letters = pw.replace(/\d/g, "").toLowerCase();
  const isVowel = (c: string) => VOWELS.includes(c);
  const pronounceable = [...letters].every(
    (c, i, arr) => i === 0 || isVowel(c) !== isVowel(arr[i - 1]),
  );
  return { pronounceable, hasDigit: /\d/.test(pw) };
}
