import { useState } from "react";
import { checkPassword, generatePassword } from "./password";
import { reverseString } from "./reverse";

export function PasswordGen() {
  const [length, setLength] = useState(12);
  const [pw, setPw] = useState(() => generatePassword(12));
  const [copied, setCopied] = useState(false);
  const check = checkPassword(pw);

  const regenerate = (len: number = length) => {
    setPw(generatePassword(len));
    setCopied(false);
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(pw);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="lab-card tt">
      <div className="mono-out" aria-live="polite">
        {pw}
      </div>

      <div className="tt-badges">
        <span className={check.pronounceable ? "tt-badge tt-badge--ok" : "tt-badge"}>
          произносимый
        </span>
        <span className={check.hasDigit ? "tt-badge tt-badge--ok" : "tt-badge"}>есть цифра</span>
        <span>{pw.length} символов</span>
      </div>

      <label className="tt-range">
        Длина: {length}
        <input
          type="range"
          min={8}
          max={24}
          value={length}
          onChange={(e) => {
            const n = Number(e.target.value);
            setLength(n);
            regenerate(n);
          }}
        />
      </label>

      <div className="tt-row">
        <button type="button" className="lab-btn" onClick={() => regenerate()}>
          Сгенерировать
        </button>
        <button type="button" className="lab-btn lab-btn--ghost" onClick={copy}>
          {copied ? "Скопировано ✓" : "Копировать"}
        </button>
      </div>
    </div>
  );
}

const MAX_LEN = 2000; // защита от переполнения стека рекурсии

export function ReverseText() {
  const [text, setText] = useState("Привет, мир!");
  const tooLong = text.length > MAX_LEN;

  return (
    <div className="lab-card tt">
      <label className="tt-label">
        Введите текст
        <textarea
          className="lab-input"
          rows={3}
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      </label>

      <div className="mono-out">{tooLong ? "" : reverseString(text)}</div>

      <p className="tt-hint">
        {tooLong
          ? `Слишком длинно: максимум ${MAX_LEN} символов (рекурсия ограничена размером стека).`
          : `Рекурсивных вызовов: ${text.length}. Без .reverse(), .split() и циклов.`}
      </p>
    </div>
  );
}
