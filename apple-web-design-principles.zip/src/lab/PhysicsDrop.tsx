import { useEffect, useRef } from "react";

const METER = 100; // 1 м = 100 px
const G = 9.8 * METER; // g = 9.8 м/с² → 980 px/s²
const RESTITUTION = 0.6; // коэффициент восстановления e при отскоке
const FRICTION = 0.5; // коэффициент трения μ о пол
const SIZE = 96;
const REST_SPEED = 30; // отскок медленнее 0.3 м/с — мяч ложится

type Body = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  roll: number;
  w: number;
  h: number;
  dragging: boolean;
  grabX: number;
  grabY: number;
  hist: { t: number; x: number; y: number }[];
};

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

export default function PhysicsDrop() {
  const arenaRef = useRef<HTMLDivElement>(null);
  const ballRef = useRef<HTMLDivElement>(null);
  const hRef = useRef<HTMLElement>(null);
  const vRef = useRef<HTMLElement>(null);
  const b = useRef<Body>({
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    roll: 0,
    w: 0,
    h: 0,
    dragging: false,
    grabX: 0,
    grabY: 0,
    hist: [],
  }).current;

  const reset = () => {
    const arena = arenaRef.current;
    if (arena) {
      b.w = arena.clientWidth;
      b.h = arena.clientHeight;
    }
    b.x = (b.w - SIZE) / 2;
    b.y = 0;
    b.vx = 0;
    b.vy = 0;
  };

  useEffect(() => {
    const arena = arenaRef.current!;
    const ball = ballRef.current!;
    b.w = arena.clientWidth;
    b.h = arena.clientHeight;
    b.x = (b.w - SIZE) / 2;

    const onResize = () => {
      b.w = arena.clientWidth;
      b.h = arena.clientHeight;
      b.x = clamp(b.x, 0, Math.max(0, b.w - SIZE));
    };
    window.addEventListener("resize", onResize);

    let raf = 0;
    let last = performance.now();
    let labelT = 0;

    const tick = (now: number) => {
      const dt = Math.min((now - last) / 1000, 1 / 60);
      last = now;
      const maxX = Math.max(0, b.w - SIZE);
      const floor = Math.max(0, b.h - SIZE);

      if (!b.dragging) {
        // gravity
        b.vy += G * dt;
        b.x += b.vx * dt;
        b.y += b.vy * dt;

        // side walls bounce with the same restitution
        if (b.x < 0) {
          b.x = 0;
          b.vx = -b.vx * RESTITUTION;
        } else if (b.x > maxX) {
          b.x = maxX;
          b.vx = -b.vx * RESTITUTION;
        }

        // floor: impact → v' = −e·v, then Coulomb friction on the slide
        if (b.y >= floor) {
          b.y = floor;
          if (b.vy > 0) {
            b.vy = -b.vy * RESTITUTION;
            if (-b.vy < REST_SPEED) b.vy = 0;
          }
          const decel = FRICTION * G * dt; // μ·g
          if (Math.abs(b.vx) <= decel) b.vx = 0;
          else b.vx -= Math.sign(b.vx) * decel;
        }

        // tiny air drag so a flick in mid-air slowly bleeds off
        b.vx *= Math.exp(-0.15 * dt);
      }

      // rolling: the ball turns by the distance it travels on the floor
      b.roll += (b.vx * dt) / (SIZE / 2);
      ball.style.transform = `translate3d(${b.x.toFixed(2)}px, ${b.y.toFixed(2)}px, 0) rotate(${b.roll.toFixed(3)}rad)`;

      labelT += dt;
      if (labelT > 0.1) {
        labelT = 0;
        if (hRef.current) hRef.current.textContent = ((floor - b.y) / METER).toFixed(2);
        if (vRef.current) vRef.current.textContent = (b.vy / METER).toFixed(2);
      }

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
    };
  }, [b]);

  const toLocal = (e: { clientX: number; clientY: number }) => {
    const r = arenaRef.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  const onDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    const p = toLocal(e);
    b.dragging = true;
    b.grabX = p.x - b.x; // keep the grab offset: no snapping to the centre
    b.grabY = p.y - b.y;
    b.vx = 0;
    b.vy = 0;
    b.hist = [{ t: performance.now(), x: p.x, y: p.y }];
  };

  const onMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!b.dragging) return;
    const p = toLocal(e);
    b.x = clamp(p.x - b.grabX, 0, Math.max(0, b.w - SIZE));
    b.y = clamp(p.y - b.grabY, 0, Math.max(0, b.h - SIZE));
    const now = performance.now();
    b.hist.push({ t: now, x: b.x, y: b.y });
    while (b.hist.length > 2 && now - b.hist[0].t > 100) b.hist.shift();
  };

  const onUp = () => {
    if (!b.dragging) return;
    b.dragging = false;
    // release velocity from the last ~100 ms of motion → the fall starts with it
    const h = b.hist;
    if (h.length >= 2) {
      const first = h[0];
      const last = h[h.length - 1];
      const dt = (last.t - first.t) / 1000;
      if (dt > 0.008) {
        b.vx = clamp((last.x - first.x) / dt, -2500, 2500);
        b.vy = clamp((last.y - first.y) / dt, -2500, 2500);
      }
    }
    b.hist = [];
  };

  return (
    <div className="lab-card">
      <div className="phys-arena" ref={arenaRef}>
        <div className="phys-floor" aria-hidden="true" />
        <div
          ref={ballRef}
          className="phys-ball"
          onPointerDown={onDown}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={onUp}
        >
          9.8
        </div>
      </div>
      <div className="phys-hud">
        <span>
          Высота: <b ref={hRef}>0.00</b> м
        </span>
        <span>
          Скорость: <b ref={vRef}>0.00</b> м/с
        </span>
        <span>g = 9.8 · e = 0.6 · μ = 0.5</span>
        <button type="button" className="lab-btn lab-btn--ghost" onClick={reset}>
          Сбросить
        </button>
      </div>
    </div>
  );
}
