/**
 * Переворачивает строку ТОЛЬКО рекурсией: без .reverse(), .split() и циклов.
 * Каждый вызов отрезает первый символ и дописывает его в конец перевёрнутого хвоста:
 *   "abc" → reverse("bc") + "a" → (reverse("c") + "b") + "a" → "cba"
 */
export function reverseString(s: string): string {
  if (s.length <= 1) return s;
  return reverseString(s.slice(1)) + s.charAt(0);
}
