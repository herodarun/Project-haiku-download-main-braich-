// Express + Zod + SQLite (better-sqlite3).
// Запуск из корня проекта:  node server/index.mjs   → http://localhost:3001

import express from "express";
import Database from "better-sqlite3";
import { z } from "zod";
import { fileURLToPath } from "node:url";

const PORT = Number(process.env.PORT) || 3001;
const db = new Database(fileURLToPath(new URL("./signups.db", import.meta.url)));

db.exec(`
  CREATE TABLE IF NOT EXISTS signups (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    email      TEXT    NOT NULL UNIQUE,
    age        INTEGER NOT NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  )
`);

const insert = db.prepare("INSERT INTO signups (email, age) VALUES (?, ?)");

// Валидация: email корректный, возраст целый и строго больше 18.
const SignupSchema = z.object({
  email: z.string().trim().email("Введите корректный email"),
  age: z.number().int("Возраст — целое число").gt(18, "Возраст должен быть больше 18"),
});

const app = express();
app.use(express.json({ limit: "10kb" }));

// CORS — чтобы клиент (Vite dev или собранная страница) мог обращаться к API.
app.use((req, res, next) => {
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.set("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

app.post("/api/signup", (req, res) => {
  const parsed = SignupSchema.safeParse(req.body ?? {});
  if (!parsed.success) {
    const errors = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      (errors[key] ??= []).push(issue.message);
    }
    return res.status(400).json({ errors });
  }

  try {
    const info = insert.run(parsed.data.email, parsed.data.age);
    return res.status(201).json({ id: Number(info.lastInsertRowid) });
  } catch (err) {
    if (String(err.message).includes("UNIQUE")) {
      return res
        .status(409)
        .json({ errors: { email: ["Этот email уже зарегистрирован"] } });
    }
    console.error(err);
    return res.status(500).json({ error: "Internal error" });
  }
});

app.listen(PORT, () => {
  console.log(`API ready: http://localhost:${PORT}/api/signup`);
});
